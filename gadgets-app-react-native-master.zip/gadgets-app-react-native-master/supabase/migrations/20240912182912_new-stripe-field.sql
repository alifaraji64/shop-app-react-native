alter table "public"."users" add column "stripe_customer_id" text;


