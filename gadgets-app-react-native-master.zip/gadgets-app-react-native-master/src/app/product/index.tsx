import { StyleSheet, Text, View } from 'react-native';

const Product = () => {
  return (
    <View>
      <Text>Product</Text>
    </View>
  );
};

export default Product;

const styles = StyleSheet.create({});
